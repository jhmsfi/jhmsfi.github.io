%% Code to generate the results in the paper
% Authors: Chenna Reddy Cotla & Alicia Uribe
% Simply run this code at the Matlab terminal to produce all the graphs in
% the paper
%% Initialization

% this is the expert rating information we are going to use in this
% excercise
expInfo = [1 3 8 10; 4 4 2 4];
% Parameters of the Model
numAgents = 1000; % Number of Agents
numAttributes = 4; % Number of attributes for each drug 
numDrugs = 2; % Number of drugs understudy


%% Exploring role of social influence

% A1, A2, A3 will have agents and their netowrk information
A1 = init_AgentsSW(numAgents, numAttributes,0,2,0); % alpha = 0.5
A2 = init_AgentsSW(numAgents, numAttributes,0.2,2,0); % alpha = 0.2
A3 = init_AgentsSW(numAgents, numAttributes,0.7,2,0); % alpha = 0.7

r1 = model(A1,expInfo);
r2 = model(A2,expInfo);
r3 = model(A3,expInfo);

s1 = mean(r1); % Mean across 30 simulations
s2 = mean(r2);
s3 = mean(r3);
Xcor = 1:100;
figure, plot(Xcor,s1,'b',Xcor,s2,'k',Xcor,s3,'g')
legend('alpha=0','alpha=0.2','alpha=0.7');
title('Role of social influence')



%% Exploring role of small world networks

% A1, A2, A3 will have agents and their netowrk information
A1 = init_AgentsSW(numAgents, numAttributes,0.5,2,0); % k=2, p = 0 Regular network
A2 = init_AgentsSW(numAgents, numAttributes,0.5,2,0.5); %k=2, p = 0.5 Small world network
A3 = init_AgentsSW(numAgents, numAttributes,0.5,2,1); %k=2, p = 1 Random network

r1 = model(A1,expInfo);
r2 = model(A2,expInfo);
r3 = model(A3,expInfo);

s1 = mean(r1); % Mean across 30 simulations
s2 = mean(r2);
s3 = mean(r3);

Xcor = 1:100;
figure, plot(Xcor,s1,'b',Xcor,s2,'k',Xcor,s3,'g')
legend('p=0','p=0.5','p=1');
title('Small World Network Example')


%% Exploring role of scale-free networks

% A1, A2 will have agents and their netowrk information
A1 = init_AgentsSF(numAgents, numAttributes,0.5,3); % d = 3 and alpha = 0.5
A2 = init_AgentsSF(numAgents, numAttributes,0.5,8); % d = 8 and alpha = 0.5


r1 = model(A1,expInfo);
r2 = model(A2,expInfo);


s1 = mean(r1); % Mean across 30 simulations
s2 = mean(r2);


Xcor = 1:100;
figure, plot(Xcor,s1,'b',Xcor,s2,'k'),hold on
legend('d=3','d=8');
title('Scale-Free Network Example')



