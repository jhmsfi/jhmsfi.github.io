function percNewDrug = model(Agent, expInfo)
% Authors : Chenna Reddy Cotla
% Model takes the agents list and their social network information and
% expert rating information to model the diffusion of new drug.

numAgents = numel(Agent); % number of Agents
numItrs=100; %Number of iteration of Iterated Prisoner's Dilemma

numSims=30;
percNewDrug = zeros(numSims,numItrs);

numAttributes = numel(expInfo(1,:));

UpdatedStates=zeros(numAgents,1);
CurrentStates=UpdatedStates;




for x= 1:numAgents
    weightedPrefs = bsxfun(@times, expInfo, Agent(x).weights);
    weightedPrefs = bsxfun(@rdivide, weightedPrefs,sqrt(sum(weightedPrefs .^2)));
    Agent(x).normalizedPrefs = weightedPrefs;
end

for sim = 1:numSims
    for iteration=1:numItrs
        
        if iteration == 1
            numInnovators = floor(0.2 * numAgents);
            randList = [ones(1,numInnovators) zeros(1,numAgents-numInnovators)];
            randList = randList(randperm(numAgents));
            UpdatedStates = randList;
            
        else
            
            for x=1:numAgents
                
                weightedPrefs = Agent(x).normalizedPrefs;
                %weightedPrefs = weightedPrefs ./ sum(weightedPrefs .^2,2);
                Nlst=Agent(x).Neighbors;
                socialPrefsA = zeros(1,numAttributes);
                socialPrefsB = zeros(1,numAttributes);
                numA = 0;
                numB = 0;
                
                for j=Nlst
                    
                    if CurrentStates(j) == 1
                        
                        socialPrefsA = socialPrefsA + Agent(j).normalizedPrefs(1,:);
                        numA = numA+1;
                    else
                        socialPrefsB = socialPrefsB + Agent(j).normalizedPrefs(2,:);
                        numB = numB+1;
                    end
                end
                
                if numA > 0
                    
                    socialPrefsA = socialPrefsA / numA;
                else
                    socialPrefsA = weightedPrefs(1,:);
                end
                if numB > 0
                    socialPrefsB = socialPrefsB / numB;
                else
                    socialPrefsB = weightedPrefs(1,:);
                end
                
                
                prefsWithSocial = (1-Agent(x).alpha) * weightedPrefs + Agent(x).alpha* [socialPrefsA;socialPrefsB] ;
                bestDrug = max(prefsWithSocial);
                closenessFromBestDrug = 1./sum((bsxfun(@minus,bestDrug,prefsWithSocial)).^2, 2);
                
                utilA = closenessFromBestDrug(1)-closenessFromBestDrug(2);
                probA = 1/(1+exp(-utilA));
                
                
                if rand < probA
                    UpdatedStates(x)=1;
                else
                    UpdatedStates(x)=0;
                end
             
            end
        end
        
        CurrentStates=UpdatedStates; % Synchrnous Updating
        percNewDrug(sim,iteration) = mean(CurrentStates(:));
        

    end
end

 
             
        
    
                
                

