   function Agent=init_AgentsSF(numAgents, numAttributes,alpha,d)
        %AGENTINIT Initializes the agents in the model.
        % Function AGENT_INIT
        
        % Define variables:
        % numAgents           -- number of Agents
        % numAttributes       -- number of Attributes for Each Drug
        % alpha               -- social influence parameter
        % d                   -- Parameter of the PA algorithm that
        % generates scale free network. d is th number of new edges you
        % introduce with in each step of PA algorithms
        
        Agent(numAgents)=struct('alpha',[],'weights',[],'Neighbors',[]);
        Neighbors=neighborhood(numAgents, d); %Nbrs is struct that contains the neighbors of each agent
        
        
        % The following code geenrates the individual weights according to
        % the distributions we have talked about in the paper
        Q = [3+randn([numAgents,1]) 4+randn([numAgents,1]) 8+randn([numAgents,1]) 9+randn([numAgents,1])];
        Q(Q < 0) = 0.1;
        Q(Q > 10) = 9.9;
        for x=1:numAgents
            
            Agent(x).alpha = alpha;
            Agent(x).weights = Q(x,:);
            Agent(x).Neighbors=Neighbors(x).lst;
            
        end

%%%%%%%%%%% UTILITY FUNCTION NEIGHBORHOOD THAT DEFINES
%%%%%%%%%%% neighbors of each agent

            
                function Nbrs=neighborhood(numAgents, d)
                %NEIGHBORHOOD defines the topology of interaction by specifying neighbors
                %of each agent
                
                              
                X=full(sf(numAgents,d));                                
                Nbrs(numAgents).lst=0;           
                for i=1:numAgents
                    
                    [~,c,~]=find(X(i,:));
                    Nbrs(i).lst=c;
                    
                end
                
            %%%%%%%%%%% UTILITY FUNCTION NEIGHBORHOOD THAT generates scale
            %%%%%%%%%%% free graph

                        
                        function A = sf(n,d)


                        if nargin == 1
                            d = 2;
                        end

                        I = [];
                        J = [];

                        for v = 1:n
                            for i = 1:d
                                M(2*((v-1)*d+i)-1) = v;
                                I = cat(1,I,v);
                                r = ceil(rand*(2*((v-1)*d+i)-1));
                                M(2*((v-1)*d+i))=M(r);
                                J = cat(1,J,M(r));
                            end
                        end

                        S = ones(length(I),1);
                        A = sign(sparse([I;J],[J;I],[S;S],n,n));
                        A = A - diag(diag(A));
