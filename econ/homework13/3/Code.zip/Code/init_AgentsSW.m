   function Agent=init_AgentsSW(numAgents, numAttributes,alpha,k, p)
        %AGENTINIT Initializes the agents in the model.
        % Function AGENT_INIT
        
        % Define variables:
        % numAgents           -- number of Agents
        % numAttributes       -- number of Attributes for Each Drug
        % alpha               -- social influence parameter
        % 2k                  -- Degree of each node in the regular graph
        % from which we create small world graph in Watts-Strogatz
        % algorithm
        % p                   -- rewiring probability
    
        
        Agent(numAgents)=struct('alpha',[],'weights',[],'Neighbors',[]);
        Neighbors=neighborhood(numAgents, k, p); %Nbrs is struct that contains the neighbors of each agent
        
        
        % The following code geenrates the individual weights according to
        % the distributions we have talked about in the paper
        Q = [3+randn([numAgents,1]) 4+randn([numAgents,1]) 8+randn([numAgents,1]) 9+randn([numAgents,1])];
        Q(Q < 0) = 0.1;
        Q(Q > 10) = 9.9;
        for x=1:numAgents
            
            Agent(x).alpha = alpha;
            Agent(x).weights = Q(x,:);
            Agent(x).Neighbors=Neighbors(x).lst;
            
        end

%%%%%%%%%%% UTILITY FUNCTION NEIGHBORHOOD THAT DEFINES
%%%%%%%%%%% neighbors of each agent
            
                function Nbrs=neighborhood(numAgents, k, p)
                %NEIGHBORHOOD defines the topology of interaction by specifying neighbors
                %of each agent
                
                              
                X=smallworld(numAgents,k, p);                                
                Nbrs(numAgents).lst=0;           
                for i=1:numAgents
                    
                    [~,c,~]=find(X(i,:));
                    Nbrs(i).lst=c;
                    
                end
                
            %%%%%%%%%%% UTILITY FUNCTION NEIGHBORHOOD THAT generates small
            %%%%%%%%%%% world graph
                        
                    function A = smallworld(n,k,p)


                    twok = 2*k;

                    I = zeros(2*k*n,1);
                    J = zeros(2*k*n,1);
                    S = zeros(2*k*n,1);

                    for count = 1:n

                        I( (count-1)*twok+1 : count*twok ) = count.*ones(twok,1);
                        J( (count-1)*twok+1 : count*twok ) = mod([count:count+k-1 n-k+count-1:n+count-2],n)+1;
                        S( (count-1)*twok+1 : count*twok ) = ones(twok,1);

                    end
                    
                    I = sparse(I,J,S,n,n);
                    I = full(I); % Here we have a regular graph
                    A = I;
                    regDegree = sum(I(:,1));
                    B = triu(A);
                    n = numel(A(1,:));
                    [r c ~] = find(B);
                    l = length(r);
                    rlist = randperm(l);
                    r = r(rlist);
                    c = c(rlist);

                    while true
                        A = I;
                        for j = 1:l
                            if rand < p

                                A(r(j),c(j)) = 0;
                                A(c(j),r(j)) = 0;

                                potList = 1:n;
                                notEligible = r(j) - regDegree/2 : r(j) + regDegree/2;
                                notEligible = mod(notEligible,n);
                                notEligible(notEligible == 0 ) = n;

                                potList(notEligible) =[];

                                m = potList(randi(length(potList)));
                                while A(r(j),m) == 1
                                    m = potList(randi(length(potList)));
                                end


                                A(r(j),m) = 1;
                                A(m,r(j)) = 1;

                            end
                        end

                        if ~any(sum(A)==0)
                            break
                        end 

                    end
