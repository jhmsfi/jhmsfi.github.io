package sim;

import java.io.FileNotFoundException;
import java.io.PrintStream;

import sim.engine.SimState;
import sim.engine.Steppable;

@SuppressWarnings("serial")
public class DataCollector implements Steppable {
	
	PrintStream out;
	RumorMill sim;
	int since = 0;
	
	double threshold = 0.995;
	
	public DataCollector(String filename, RumorMill sim) {
		this.sim = sim;
		threshold = sim.getConversionThreshold();			// we use this for an "extreme of the extremes" threshold even if conversion is not set
		if (filename.equals("")) {
			out = System.out;
		} else {
			try {
				out = new PrintStream(filename);
			}
			catch (FileNotFoundException e) {
				System.err.println("Could not create a file with that name, so switching output to console. Problem:");
				e.printStackTrace();
				out = System.out;
			}
		}
		out.println("step\trumor.mean\trumor.sd\tact.mean\tact.sd\tknow.prop\trumor.lox\trumor.lo5\trumor.gt50\trumor.hi5\trumor.hix\tn.quashers" +
				"\tn.spreaders\tlevel.bin.0\tlevel.bin.1\tlevel.bin.2\tlevel.bin.3\tlevel.bin.4\tlevel.bin.5\tlevel.bin.6\tactivity.bin.0" +
				"\tactivity.bin.1\tactivity.bin.2\tactivity.bin.3\tactivity.bin.4\tactivity.bin.5\tactivity.bin.6");
	}

	@Override
	public void step(SimState state) {
		if (since != 0) {				// these first few lines give us output on step 0 and every step thereafter
			since--;
			return;
		}
		since = 999;
		long step = sim.schedule.getSteps();
		double rumorMean = 0;
		double activityMean = 0;
		double rumorSS = 0;
		double activitySS = 0;
		int nKnow = 0;
		int nLoExtreme = 0;
		int nHiExtreme = 0;
		int nAbove50 = 0;
		int nAbove95 = 0;
		int nBelow5 = 0;
		int nTotal = 0;
		int nQuashers = 0;
		int nSpreaders = 0;
		int nLevBin0, nLevBin1, nLevBin2, nLevBin3, nLevBin4, nLevBin5, nLevBin6;
		nLevBin0 = nLevBin1 = nLevBin2 = nLevBin3 = nLevBin4 = nLevBin5 = nLevBin6 = 0;
		int nActBin0, nActBin1, nActBin2, nActBin3, nActBin4, nActBin5, nActBin6;
		nActBin0 = nActBin1 = nActBin2 = nActBin3 = nActBin4 = nActBin5 = nActBin6 = 0;
		Object[][] agents = sim.netspace.field;
		for (Object[] rowofagents : agents) {
			for (Object aobject : rowofagents) {
				Agent a = (Agent)aobject;
				double level = a.rumorLevel;
				double activity = a.activityLevel;
				nTotal++;
				if (a.knows) {
					nKnow++;
				}
				if (a.fixedRumor) {
					if (a.rumorLevel > 0) {
						nSpreaders++;
					} else {
						nQuashers++;
					}
				}
				double rumorDelta = level - rumorMean;
				double activityDelta = activity - activityMean;
				rumorMean += rumorDelta / nTotal;
				activityMean += activityDelta / nTotal;
				rumorSS += rumorDelta * (level - rumorMean);
				activitySS += activityDelta * (activity - activityMean);
				if (level > 0) {
					nAbove50++;
					if (level > 0.9) {
						nAbove95++;
					}
					if (level > threshold) {
						nHiExtreme++;
					}
				} else {
					if (level < -0.9) {
						nBelow5++;
					}
					if (level < -threshold) {
						nLoExtreme++;
					}
				}
				if (level < -1.0 + 2d/7) {
					nLevBin0++;
				} else if (level < -1.0 + 4d/7) {
					nLevBin1++;
				} else if (level < -1.0 + 6d/7) {
					nLevBin2++;
				} else if (level < -1.0 + 8d/7) {
					nLevBin3++;
				} else if (level < -1.0 + 10d/7) {
					nLevBin4++;
				} else if (level < -1.0 + 12d/7) {
					nLevBin5++;
				} else {
					nLevBin6++;
				}
				if (activity < 1d/7) {
					nActBin0++;
				} else if (activity < 2d/7) {
					nActBin1++;
				} else if (activity < 3d/7) {
					nActBin2++;
				} else if (activity < 4d/7) {
					nActBin3++;
				} else if (activity < 5d/7) {
					nActBin4++;
				} else if (activity < 6d/7) {
					nActBin5++;
				} else {
					nActBin6++;
				}
			}
		}
		double rumorSD = Math.sqrt(rumorSS / (nTotal - 1));
		double activitySD = Math.sqrt(activitySS / (nTotal - 1));
		double propKnow = (double)nKnow / nTotal;
		double propLoExtreme = (double)nLoExtreme / nTotal;
		double propHiExtreme = (double)nHiExtreme / nTotal;
		double propAbove50 = (double)nAbove50 / nTotal;
		double propAbove95 = (double)nAbove95 / nTotal;
		double propBelow5 = (double)nBelow5 / nTotal;
		out.println(step + "\t" + rumorMean + "\t" + rumorSD + "\t" + activityMean + "\t" + activitySD + "\t" + propKnow + "\t" + propLoExtreme +
				"\t" + propBelow5 + "\t" + propAbove50 + "\t" + propAbove95 + "\t" + propHiExtreme + "\t" + nQuashers + "\t" + nSpreaders + "\t" +
				nLevBin0 + "\t" + nLevBin1 + "\t" + nLevBin2 + "\t" + nLevBin3 + "\t" + nLevBin4 + "\t" + nLevBin5 + "\t" + nLevBin6 + "\t" +
				nActBin0 + "\t" + nActBin1 + "\t" + nActBin2 + "\t" + nActBin3 + "\t" + nActBin4 + "\t" + nActBin5 + "\t" + nActBin6);
		return;
	}
	
}
