package sim;

import java.util.HashSet;

import sim.engine.SimState;
import sim.field.grid.ObjectGrid2D;
import sim.util.Int2D;

@SuppressWarnings("serial")
public class RumorMill extends SimState {
	
	ObjectGrid2D netspace;
	DataCollector observer;
	
	protected int gridWidth = 100;
	protected int gridHeight = 100;
	protected int numSpreaders = 25;
	protected int numQuashers = 25;
	protected int numInitialSpreadersIn = 1;
	protected int numInitialQuashersIn = 0;
	protected double activityDecay = 0.95;
	protected double activityIncrement = 0.1;
	protected double influenceDiscountRate = 3.0;		// this is gamma, the steepness of the dip in the curve for decreasing influence of disparate opinions
	protected double influenceMaximum = 1.0;			// this is beta, the maximum influence proportion possible
	protected boolean quasherFixedActivity = false;
	protected double quasherActivity = 0;				// this only applies if quasherFixedActivity is true
	protected boolean trueBelievers = false;
	protected double conversionThreshold = 0.995;		// rumor level (absolute value) at which agent considers becoming a "True Believer"; note this is also used for data collection even when trueBelievers is false
	protected double conversionProbability = 0.1;		// probability of becoming a "True Believer" when rumor level extreme is achieved (only applies if trueBelievers is true)
	protected String datafile = "";

	public RumorMill(long seed) {
		super(seed);
	}
	
	public void start() {
		super.start();
		makeNet();
		makeAgents();
		makeDataCollector();
		scheduleFirst();
		return;
	}
	
	private void makeNet() {
		netspace = new ObjectGrid2D(gridWidth, gridHeight);
		return;
	}
	
	private void makeAgents() {
		for (int x = 0; x < gridWidth; x++) {
			for (int y = 0; y < gridHeight; y++) {
				double rumorLevel = random.nextDouble() * 2 - 1;
				double activityLevel = random.nextDouble();
				Agent agent = new Agent(x, y, rumorLevel, activityLevel, this);
				agent.setActivityDecay(activityDecay).setActivityIncrement(activityIncrement).setInfluenceDiscountRate(influenceDiscountRate).setInfluenceMaximum(influenceMaximum);
				if (trueBelievers) {
					agent.setTrueBelievable(conversionThreshold, conversionProbability);
				}
				netspace.set(x, y, agent);
			}
		}
		HashSet<Int2D> spreaders = new HashSet<>();
		HashSet<Int2D> quashers = new HashSet<>();
		for (int i = 0; i < numSpreaders; i++) {
			Int2D loc;
			do {
				loc = new Int2D(random.nextInt(gridWidth), random.nextInt(gridHeight));
			} while (!spreaders.add(loc));													// this ensures unique locations for spreaders
		}
		for (int i = 0; i < numQuashers; i++) {
			Int2D loc;
			do {
				loc = new Int2D(random.nextInt(gridWidth), random.nextInt(gridHeight));
			} while (!spreaders.contains(loc) && !quashers.add(loc));						// ditto quashers, also avoiding previously designated spreaders
		}
		int spreadknow = numInitialSpreadersIn;
		int quashknow = numInitialQuashersIn;
		for (Int2D spreaderloc : spreaders) {
			Agent spreader = (Agent)netspace.get(spreaderloc.x, spreaderloc.y);
			spreader.setPartisan(1);
			if (spreadknow > 0) {
				spreader.tell();
				spreadknow--;
			}
		}
		for (Int2D quasherloc : quashers) {
			Agent quasher = (Agent)netspace.get(quasherloc.x, quasherloc.y);
			quasher.setPartisan(-1);
			if (quasherFixedActivity) {
				quasher.setFixedQuashStrategy(quasherActivity);
			}
			if (quashknow > 0) {
				quasher.tell();
				quashknow--;
			}
		}
		return;
	}
	
	private void makeDataCollector() {
		observer = new DataCollector(datafile, this);
		return;
	}
	
	/**
	 * This simply picks a random agent to go first and schedules it. From here on out, remaining events will be scheduled by the agent.
	 */
	private void scheduleFirst() {
		scheduleNextPlayer();
		return;
	}
	
	/**
	 * Schedules a random agent to go on the next move. Also schedules the data collector.
	 */
	public void scheduleNextPlayer() {
		schedule.scheduleOnce((Agent)netspace.get(random.nextInt(gridWidth), random.nextInt(gridHeight)),0);
		schedule.scheduleOnce(observer,10);
		return;
	}
	
	///////////////////////
	// SETTERS & GETTERS //
	///////////////////////
	
	public int getGridWidth() {
		return gridWidth;
	}

	public void setGridWidth(int gw) {
		if (gw > 2) {
			gridWidth = gw;
		}
		return;
	}
	
	public int getGridHeight() {
		return gridHeight;
	}

	public void setGridHeight(int gridHeight) {
		if (gridHeight > 2) {
			this.gridHeight = gridHeight;
		}
		return;
	}

	public int getNumSpreaders() {
		return numSpreaders;
	}

	public void setNumSpreaders(int numSpreaders) {
		if (numSpreaders < gridHeight * gridWidth) {
			this.numSpreaders = numSpreaders;
		}
		return;
	}

	public int getNumQuashers() {
		return numQuashers;
	}

	public void setNumQuashers(int numQuashers) {
		if (numQuashers < gridHeight * gridWidth) {
			this.numQuashers = numQuashers;
		}
		return;
	}

	public int getNumInitialSpreadersIn() {
		return numInitialSpreadersIn;
	}

	public void setNumInitialSpreadersIn(int numInitialSpreadersIn) {
		if (numInitialSpreadersIn <= numSpreaders) {
			this.numInitialSpreadersIn = numInitialSpreadersIn;
		}
		return;
	}

	public int getNumInitialQuashersIn() {
		return numInitialQuashersIn;
	}

	public void setNumInitialQuashersIn(int numInitialQuashersIn) {
		if (numInitialQuashersIn <= numQuashers) {
			this.numInitialQuashersIn = numInitialQuashersIn;
		}
		return;
	}

	public double getActivityDecay() {
		return activityDecay;
	}

	public void setActivityDecay(double activityDecay) {
		if (activityDecay <= 1 && activityDecay >= 0) {
			this.activityDecay = activityDecay;
		}
		return;
	}

	public double getActivityIncrement() {
		return activityIncrement;
	}

	public void setActivityIncrement(double activityIncrement) {
		if (activityIncrement <= 1 && activityIncrement >= 0) {
			this.activityIncrement = activityIncrement;
		}
		return;
	}

	public double getInfluenceDiscountRate() {
		return influenceDiscountRate;
	}

	public void setInfluenceDiscountRate(double influenceDiscountRate) {
		this.influenceDiscountRate = influenceDiscountRate;
	}

	public double getInfluenceMaximum() {
		return influenceMaximum;
	}

	public void setInfluenceMaximum(double influenceMaximum) {
		if(influenceMaximum <= 1 && influenceMaximum >= 0) {
			this.influenceMaximum = influenceMaximum;
		}
		return;
	}
	
	public boolean isQuasherFixedActivity() {
		return quasherFixedActivity;
	}

	public void setQuasherFixedActivity(boolean quasherFixedActivity) {
		this.quasherFixedActivity = quasherFixedActivity;
		return;
	}

	public double getQuasherActivity() {
		return quasherActivity;
	}

	public void setQuasherActivity(double quasherActivity) {
		if (quasherActivity >= 0 && quasherActivity <= 1) {
			this.quasherActivity = quasherActivity;
		}
		return;
	}
	
	public boolean isTrueBelievers() {
		return trueBelievers;
	}

	public void setTrueBelievers(boolean trueBelievers) {
		this.trueBelievers = trueBelievers;
		return;
	}

	public double getConversionThreshold() {
		return conversionThreshold;
	}

	public void setConversionThreshold(double conversionThreshold) {
		if (conversionThreshold >= 0 && conversionThreshold <= 1) {
			this.conversionThreshold = conversionThreshold;
		}
		return;
	}

	public double getConversionProbability() {
		return conversionProbability;
	}

	public void setConversionProbability(double conversionProbability) {
		if (conversionProbability >= 0 && conversionProbability <= 1) {
			this.conversionProbability = conversionProbability;
		}
		return;
	}

	public String getDataFilename() {
		return datafile;
	}
	
	public void setDataFilename(String df) {
		datafile = df;
		return;
	}

	//////////       M   M     A     I   NN  N
	// MAIN //       MM MM    AAA    I   N N N
	//////////       M M M   A   A   I   N  NN
	
	public static void main(String[] args) {
		doLoop(RumorMill.class, args);
		System.exit(0);
	}
}
