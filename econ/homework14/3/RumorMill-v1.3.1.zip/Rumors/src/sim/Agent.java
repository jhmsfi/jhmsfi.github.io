package sim;

import java.awt.Color;
import java.awt.Graphics2D;

import sim.engine.SimState;
import sim.engine.Steppable;
import sim.portrayal.DrawInfo2D;
import sim.portrayal.SimplePortrayal2D;
import sim.portrayal.simple.OvalPortrayal2D;

@SuppressWarnings("serial")
public class Agent implements Steppable {
	
	protected double rumorLevel = 0;
	protected double activityLevel = 0;
	protected boolean knows = false;
	protected boolean fixedRumor = false;
	protected boolean fixedActivity = false;
	protected boolean trueBeliever = false;
	protected double conversionThreshold = 0.995;
	protected double conversionProbability = 0.1;
	
	private boolean originalBeliever = false;
	
	protected int x, y;
	protected RumorMill sim;
	
	protected double activityDecay;
	protected double activityIncrement;
	protected double influenceDiscountRate;
	protected double influenceMaximum;
	
	private SimplePortrayal2D portrayalLev;
	private SimplePortrayal2D portrayalAct;
	
	public Agent(int x, int y, double rumorLevel, double activityLevel, RumorMill sim) {
		this.x = x;
		this.y = y;
		this.rumorLevel = rumorLevel;
		this.activityLevel = activityLevel;
		this.sim = sim;
	}
	
	///////////////////
	// Setup Methods //
	///////////////////
	
	public Agent setActivityDecay(double activityDecay) {
		this.activityDecay = activityDecay;
		return this;
	}

	public Agent setActivityIncrement(double activityIncrement) {
		this.activityIncrement = activityIncrement;
		return this;
	}

	public Agent setInfluenceDiscountRate(double influenceDiscountRate) {
		this.influenceDiscountRate = influenceDiscountRate;
		return this;
	}

	public Agent setInfluenceMaximum(double influenceMaximum) {
		this.influenceMaximum = influenceMaximum;
		return this;
	}

	public void setPartisan(double rumorLevel) {
		fixedRumor = true;
		originalBeliever = true;					// we store this so we can distinguish converts from the setup Partisans
		this.rumorLevel = rumorLevel;
		return;
	}
	
	public void setFixedQuashStrategy(double activityLevel) {
		fixedActivity = true;
		this.activityLevel = activityLevel;
		return;
	}
	
	public void setTrueBelievable(double conversionThreshold, double conversionProbability) {
		trueBeliever = true;
		this.conversionThreshold = conversionThreshold;
		this.conversionProbability = conversionProbability;
		return;
	}
	
	public void tell() {
		knows = true;
		return;
	}
	
	/////////////////
	// STEP METHOD //
	/////////////////
	
	public void step(SimState state) {
		Agent partner;
		int partnerwheel = sim.random.nextInt(8);
		int dx = 0;
		int dy = 0;
		int ox, oy;
		switch (partnerwheel) {
			case 0:
				dx = -1;
				dy = -1;
				break;
			case 1:
				dy = -1;
				break;
			case 2:
				dx = 1;
				dy = -1;
				break;
			case 3:
				dx = -1;
				break;
			case 4:
				dx = 1;
				break;
			case 5:
				dx = -1;
				dy = 1;
				break;
			case 6:
				dy = 1;
				break;
			case 7:
				dx = 1;
				dy = 1;
				break;
		}
		ox = sim.netspace.tx(dx + x);
		oy = sim.netspace.ty(dy + y);
		partner = (Agent)sim.netspace.get(ox, oy);
		if (!knows && !partner.knows) {
			decayActivity(partner);
			sim.scheduleNextPlayer();
			return;
		}
		double probinteract = activityLevel + partner.activityLevel - activityLevel * partner.activityLevel;
		if (sim.random.nextDouble() > probinteract) {
			decayActivity(partner);
			sim.scheduleNextPlayer();
			return;
		}
		// at this point, we've decided to interact
		incrementActivity(partner);
		tell();								// make sure both know
		partner.tell();
		double Rm = rumorLevel;				// we need the original values (both for "synchronous" calc & in case one gets converted to a True Believer)
		double Ro = partner.rumorLevel;
		double diff = Math.abs(Rm - Ro);
		double b = influenceMaximum;
		double g = influenceDiscountRate;
		double lambda = (b / (1 - Math.exp(-2*g))) * (Math.exp(-1*g*diff)-Math.exp(-2*g));
		boolean myFlag, pFlag;
		if (!fixedRumor) {
			if (!trueBeliever) {
				myFlag = true;
			} else if (Math.abs(rumorLevel) < conversionThreshold) {
				myFlag = true;
			} else {
				if (conversionProbability < sim.random.nextDouble()) {
					myFlag = true;
				} else {
					myFlag = false;
					fixedRumor = true;
					rumorLevel = 1 * Math.signum(rumorLevel);
				}
			}
		} else {
			myFlag = false;
		}
		if (!partner.fixedRumor) {
			if (!partner.trueBeliever) {
				pFlag = true;
			} else if (Math.abs(partner.rumorLevel) < partner.conversionThreshold) {
				pFlag = true;
			} else {
				if (partner.conversionProbability < sim.random.nextDouble()) {
					pFlag = true;
				} else {
					pFlag = false;
					partner.fixedRumor = true;
					partner.rumorLevel = 1 * Math.signum(partner.rumorLevel);
				}
			}
		} else {
			pFlag = false;
		}
		if (myFlag) {
			rumorLevel = lambda * Ro + (1 - lambda) * Rm;
			if (rumorLevel > 1) {
				rumorLevel = 1;
			} else if (rumorLevel < -1) {
				rumorLevel = -1;
			}
		}
		if (pFlag) {
			partner.rumorLevel = lambda * Rm + (1 - lambda) * Ro;
			if (partner.rumorLevel > 1) {
				partner.rumorLevel = 1;
			} else if (partner.rumorLevel < -1) {
				partner.rumorLevel = -1;
			}
		}
		sim.scheduleNextPlayer();
		return;
	}
	
	/////////////
	// Workers //
	/////////////
	
	protected void incrementActivity(Agent partner) {
		if (!fixedActivity) {
			activityLevel = 1 - (1/((1/(1-activityLevel)) + activityIncrement));
		}
		if (!partner.fixedActivity) {
			partner.activityLevel = 1 - (1/((1/(1-partner.activityLevel)) + activityIncrement));
		}
		return;
	}
	
	protected void decayActivity(Agent partner) {
		if (!fixedActivity) {
			activityLevel = activityLevel * activityDecay;
		}
		if (!partner.fixedActivity) {
			partner.activityLevel = partner.activityLevel * activityDecay;
		}
		return;
	}
	
	////////////////////////////
	// Getters for inspection //
	////////////////////////////
	
	public double getRumorLevel() {
		return rumorLevel;
	}

	public double getActivityLevel() {
		return activityLevel;
	}

	public boolean isKnows() {
		return knows;
	}

	public boolean isFixedRumor() {
		return fixedRumor;
	}
	
	public boolean isOriginalBeliever() {
		return originalBeliever;
	}

	public boolean isFixedActivity() {
		return fixedActivity;
	}

	///////////////////////////////////////
	// Portrayal makers / anon rendering //
	///////////////////////////////////////
	
	public SimplePortrayal2D makeLevelPortrayal() {
		portrayalLev = new OvalPortrayal2D() {
			public void draw(Object obj, Graphics2D gra, DrawInfo2D drw) {
				float mred = 1.0f;
				float mgreen = 1.0f;
				float mblue = 1.0f;
				if (rumorLevel > 0) {
					mgreen = mblue = 1 - (float)rumorLevel;
				} else if (rumorLevel < 0) {
					mgreen = mred = 1 + (float)rumorLevel;
				}
				paint = new Color(mred,mgreen,mblue);
				scale = 1;
				super.draw(obj,gra,drw);
			}

		};
		
		return portrayalLev;
	}
	
	public SimplePortrayal2D makeActivityPortrayal() {
		portrayalAct = new OvalPortrayal2D() {
			public void draw(Object obj, Graphics2D gra, DrawInfo2D drw) {
				float mred = (float)activityLevel;
				float mgreen = (float)activityLevel * 0.5f;
				float mblue = 0.0f;
				paint = new Color(mred,mgreen,mblue);
				scale = 1;
				super.draw(obj,gra,drw);
			}

		};
		
		return portrayalAct;
	}
	
}
