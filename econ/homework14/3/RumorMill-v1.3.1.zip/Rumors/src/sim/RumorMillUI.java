package sim;

import java.awt.Color;

import javax.swing.JFrame;

import sim.display.Console;
import sim.display.Controller;
import sim.display.Display2D;
import sim.display.GUIState;
import sim.engine.SimState;
import sim.portrayal.grid.ObjectGridPortrayal2D;

public class RumorMillUI extends GUIState {	// TODO add counter for all frozen-opinion agents
	
	public Display2D displayLevel;
	public Display2D displayActiv;
	public JFrame displayFrameLevel;
	public JFrame displayFrameActiv;
	ObjectGridPortrayal2D fieldportLevel;
	ObjectGridPortrayal2D fieldportActiv;

	public RumorMillUI() {
		super(new RumorMill(System.currentTimeMillis()));
		fieldportLevel = new ObjectGridPortrayal2D();
		fieldportActiv = new ObjectGridPortrayal2D();
	}
	
	public void load(SimState state) {
		super.load(state);
		setupPortrayals();
		displayLevel.repaint();
		displayActiv.repaint();
		return;
	}
	
	public void init(Controller c) {
		super.init(c);
		int height = (int)(0.8 * java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().height);
		displayLevel = new Display2D(height,height,this);
		displayActiv = new Display2D(height, height, this);
		displayFrameLevel = displayLevel.createFrame();
		displayFrameLevel.setTitle("Rumor Level");
		displayFrameActiv = displayActiv.createFrame();
		displayFrameActiv.setTitle("Activity Level");
		c.registerFrame(displayFrameLevel);
		c.registerFrame(displayFrameActiv);
		displayFrameLevel.setVisible(true);
		displayFrameActiv.setVisible(true);
		Color c3 = Color.BLACK;
		displayLevel.setBackdrop(c3);
		displayActiv.setBackdrop(c3);
		displayLevel.attach(fieldportLevel, "RumorMill Rumor Level");
		displayActiv.attach(fieldportActiv, "RumorMill Activity Level");
		return;
	}
	
	public void start() {
		super.start();
		setupPortrayals();
		displayLevel.reset();
		displayLevel.repaint();
		displayActiv.reset();
		displayActiv.repaint();
		return;
	}
	
	public void quit() {
		super.quit();

		if (displayFrameLevel !=null) {
			displayFrameLevel.dispose();
		}
		displayFrameLevel = null;
		displayLevel = null;

		if (displayFrameActiv !=null) {
			displayFrameActiv.dispose();
		}
		displayFrameActiv = null;
		displayActiv = null;

		return;
	}


	public void setupPortrayals() {
		RumorMill rm = (RumorMill)state;
		fieldportLevel.setField(rm.netspace);
		fieldportActiv.setField(rm.netspace);
		Object[][] agents = rm.netspace.field;
		for (Object[] rowofagents : agents) {
			for (Object aobject : rowofagents) {
				Agent a = (Agent)aobject;
				fieldportLevel.setPortrayalForObject(a, a.makeLevelPortrayal());
				fieldportActiv.setPortrayalForObject(a, a.makeActivityPortrayal());
			}
		}
		return;
	}
	
	public Object getSimulationInspectedObject() {
		return state;
	}
	
	//////////       M   M     A     I   NN  N
	// MAIN //       MM MM    AAA    I   N N N
	//////////       M M M   A   A   I   N  NN
	
	public static void main(String[] args) {
		RumorMillUI ui = new RumorMillUI();
		Console con = new Console(ui);
		con.setVisible(true);
		System.out.println("Starting Simulation UI");
	}


}
