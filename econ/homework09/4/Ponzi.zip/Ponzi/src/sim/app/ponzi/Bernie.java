/*
  Copyright 2006 by Sean Luke and George Mason University
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
 */

package sim.app.ponzi;

import sim.engine.*;

public/* strictfp */class Bernie implements Steppable
{
	public double advertisedROI;
	
	public double accountBalance;
	
	public Bernie(final SimState state)
	{
		accountBalance = 0;
	}

	public void step(final SimState state)
	{
		PonziScheme ponziScheme = (PonziScheme) state;

		if (accountBalance < 0)
		{
			System.err.println("Bernie was caught in his game");
		}
		
		Market market = ponziScheme.getMarket();
		
		advertisedROI = market.getTrueROI() + ponziScheme.amountOfOverReporting;
		
		if (accountBalance < 0)
		{
			state.finish();
		}
	}
	
	public void substractFromBalance(double amount)
	{
		accountBalance = accountBalance - amount;
	}
	
	public void addToBalance(double amount)
	{
		accountBalance = accountBalance + amount;
	}
	
	public double getAdvertisedROI()
	{
		return advertisedROI;
	}
	
	public double getAccountBalance()
	{
		return accountBalance;
	}
}
