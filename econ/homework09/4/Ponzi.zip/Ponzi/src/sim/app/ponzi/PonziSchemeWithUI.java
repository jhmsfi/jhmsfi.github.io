/*
  Copyright 2006 by Sean Luke and George Mason University
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
 */

package sim.app.ponzi;

import sim.engine.*;
import sim.display.*;
import sim.portrayal.grid.*;
import sim.util.media.chart.TimeSeriesChartGenerator;

import java.awt.*;
import javax.swing.*;

import org.jfree.data.xy.XYSeries;

public class PonziSchemeWithUI extends GUIState
{
	public Display2D display;

	public JFrame displayFrame;

	FastValueGridPortrayal2D agentPortrayal = new FastValueGridPortrayal2D(
		"Agents");

	TimeSeriesChartGenerator chartGenerator;
	
	TimeSeriesChartGenerator accountBalanceChartGenerator;

	public static void main(String[] args)
	{
		PonziSchemeWithUI schelling = new PonziSchemeWithUI();
		Console c = new Console(schelling);
		c.setVisible(true);
	}

	public PonziSchemeWithUI()
	{
		super(new PonziScheme(System.currentTimeMillis()));
	}

	public PonziSchemeWithUI(SimState state)
	{
		super(state);
	}

	public static String getName()
	{
		return "Ponzi Scheme";
	}

	public Object getSimulationInspectedObject()
	{
		return state;
	} // non-volatile

	public void start()
	{
		super.start();
		// set up our portrayals
		setupPortrayals();
		setupGraphs();
	}

	public void load(SimState state)
	{
		super.load(state);
		// we now have new grids. Set up the portrayals to reflect that
		setupPortrayals();
	}

	// This is called by start() and by load() because they both had this code
	// so I didn't have to type it twice :-)
	public void setupPortrayals()
	{
		agentPortrayal.setMap(new sim.util.gui.SimpleColorMap(new Color[] {
				new Color(0, 0, 0, 0), new Color(64, 64, 64), Color.red,
				Color.blue }));
		agentPortrayal.setField(((PonziScheme) state).neighbors);

		// reschedule the displayer
		display.reset();

		// redraw the display
		display.repaint();
	}

	public void setupGraphs()
	{
		// Set up linear chart

		PonziScheme ponziScheme = (PonziScheme) state;

		chartGenerator.removeAllSeries();
		accountBalanceChartGenerator.removeAllSeries();

		final XYSeries percentageStandingSeries = new XYSeries(
			"Percentage Agents Standing");

		percentageStandingSeries.add(state.schedule.getSteps(), ponziScheme
			.getPercentageInvestor());
		
		final XYSeries advertisedROISeries = new XYSeries("Advertised ROI");
		
		advertisedROISeries.add(state.schedule.getSteps(), ponziScheme.getBernie().getAdvertisedROI());
		
		final XYSeries actualROISeries = new XYSeries("Actual ROI");
	
		actualROISeries.add(state.schedule.getSteps(), ponziScheme.getMarket().getTrueROI());

		final XYSeries accountBalanceSeries = new XYSeries("Bernie's Account Balance");
		
		accountBalanceSeries.add(state.schedule.getSteps(), ponziScheme
				.getBernie().getAccountBalance());
		
		chartGenerator.addSeries(percentageStandingSeries, null);
		chartGenerator.addSeries(advertisedROISeries, null);
		chartGenerator.addSeries(actualROISeries, null);
		accountBalanceChartGenerator.addSeries(accountBalanceSeries, null);

		Steppable chartUpdater = new Steppable()
		{
			public void step(SimState state)
			{
				PonziScheme ponziScheme = (PonziScheme) state;

				percentageStandingSeries.add(state.schedule.getSteps(),
						ponziScheme.getPercentageInvestor());
				
				advertisedROISeries.add(state.schedule.getSteps(), ponziScheme.getBernie().getAdvertisedROI());
				
				actualROISeries.add(state.schedule.getSteps(), ponziScheme.getMarket().getTrueROI());
				
				accountBalanceSeries.add(state.schedule.getSteps(),
						ponziScheme.getBernie().getAccountBalance());
				
				System.err.println("Bernie Account Balance: " + ponziScheme.getBernie().getAccountBalance());
			}
		};

		this.scheduleImmediateRepeat(true, chartUpdater);
	}

	public void init(Controller c)
	{
		super.init(c);

		// Make the Display2D. We'll have it display stuff later.
		display = new Display2D(400, 400, this, 1); // at 400x400, we've got 4x4
		// per array position
		displayFrame = display.createFrame();
		c.registerFrame(displayFrame); // register the frame so it appears in
		// the "Display" list
		displayFrame.setVisible(true);

		// attach the portrayals
		display.attach(agentPortrayal, "Investors");

		// specify the backdrop color -- what gets painted behind the displays
		display.setBackdrop(Color.black);
		
		// Init linear chart
		chartGenerator = new TimeSeriesChartGenerator();
		chartGenerator.setTitle("Number Investing");

		chartGenerator.setDomainAxisLabel("Time");
		chartGenerator.setRangeAxisLabel("Number Investing");

		JFrame chartGeneratorFrame = chartGenerator.createFrame(this);
		chartGeneratorFrame.setVisible(true);

		c.registerFrame(chartGeneratorFrame);
		
		// Init chart
		accountBalanceChartGenerator = new TimeSeriesChartGenerator();
		accountBalanceChartGenerator.setTitle("Bernie's Account Balance");

		accountBalanceChartGenerator.setDomainAxisLabel("Time");
		accountBalanceChartGenerator.setRangeAxisLabel("Account Balance");

		chartGeneratorFrame = accountBalanceChartGenerator.createFrame(this);
		chartGeneratorFrame.setVisible(true);

		c.registerFrame(chartGeneratorFrame);
	}

	public void quit()
	{
		super.quit();

		if (displayFrame != null)
			displayFrame.dispose();
		displayFrame = null; // let gc
		display = null; // let gc
	}
}
