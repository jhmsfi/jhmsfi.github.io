/*
  Copyright 2006 by Sean Luke and George Mason University
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
 */

package sim.app.ponzi;

import java.util.HashSet;
import java.util.Set;

import sim.util.*;
import sim.engine.*;

public/* strictfp */class Investor implements Steppable
{
	Int2D loc;
	
	Set<Investor> neighbors = new HashSet<Investor>();
	
	double accountBalance = 1000;
	
	boolean currentlyInvesting = false;

	//	Return from investment before investor will invest
	double investorMarketThreshold;  
	
	double weightInvestorMarketThreshold;
	
	// Percentage of neighbors that need to join investment
	double investorSocialThreshold;
	
	double weightInvestorSocialThreshold;

	public Investor(int x, int y, final SimState state)
	{
		neighbors.clear();
		
		PonziScheme ponziScheme = (PonziScheme) state;

		loc = new Int2D(x, y);

		investorMarketThreshold = state.random.nextGaussian()
				* ponziScheme.sdInvestorMarketThreshold
				+ ponziScheme.meanInvestorMarketThreshold;

		weightInvestorMarketThreshold = state.random.nextGaussian()
				* ponziScheme.sdWeightInvestorMarketThreshold
				+ ponziScheme.meanWeightInvestorMarketThreshold;
		
		investorSocialThreshold = state.random.nextGaussian() 
				* ponziScheme.sdInvestorSocialThreshold
				+ ponziScheme.meanInvestorSocialThreshold;
		
		weightInvestorSocialThreshold = state.random.nextGaussian()
				* ponziScheme.sdWeightInvestorSocialThreshold
				+ ponziScheme.meanWeightInvestorSocialThreshold;

		int[][] locs = ponziScheme.neighbors.field;
	}
	
	public int getNumberNeighbors()
	{
		return neighbors.size();
	}

	public void step(final SimState state)
	{
		PonziScheme ponziScheme = (PonziScheme) state;

		int[][] locs = ponziScheme.neighbors.field;
		
		if (state.schedule.getSteps() > 0)
		{
			if (currentlyInvesting)
			{
				double probSelling = calculateProbabilityOfSelling(ponziScheme);
				
				if (ponziScheme.random.nextDouble() < probSelling)
				{
					// Sell the investment
					currentlyInvesting = false;
					
					// Subtract from Bernie's account balance
					
					System.err.println("Investor cashed in and received: " + accountBalance);
					
					ponziScheme.getBernie().substractFromBalance(accountBalance);
					
					locs[loc.x][loc.y] = ponziScheme.BLUE;
				}
				else
				{
					// Update you expected returns
					accountBalance = accountBalance + accountBalance * ponziScheme.getBernie().getAdvertisedROI()/52.0;
				}
			}
			else
			{
				double probInvesting = calculateProbabilityOfInvesting(ponziScheme);
				
				if (ponziScheme.random.nextDouble() < probInvesting)
				{
					currentlyInvesting = true;
					
					ponziScheme.getBernie().addToBalance(accountBalance);
					
					locs[loc.x][loc.y] = ponziScheme.RED;
				}
			}
		}
	}

	public double calculateProbabilityOfInvesting(PonziScheme ponziScheme)
	{
		// This should only be called if not currently investing
		
		double probInvesting = 0;
		
		Bernie bernie = ponziScheme.getBernie();
		
		if (bernie.getAdvertisedROI() > investorMarketThreshold)
		{
			probInvesting += weightInvestorMarketThreshold;
		}
		
		if (getPercentageNeighborsInvesting() > investorSocialThreshold)
		{
			probInvesting += weightInvestorSocialThreshold;
		}
		
		return probInvesting;
	}
	
	public double calculateProbabilityOfSelling(PonziScheme ponziScheme)
	{
		// This should only be called if currently investing
		
		double probSelling = 0;
		
		Bernie bernie = ponziScheme.getBernie();
		
		if (bernie.getAdvertisedROI() < investorMarketThreshold)
		{
			probSelling += weightInvestorMarketThreshold;
		}
		
		if (getPercentageNeighborsInvesting() < investorSocialThreshold)
		{
			probSelling += weightInvestorSocialThreshold;
		}
		
		return probSelling;
	}
	
	public double getPercentageNeighborsInvesting()
	{
		double numNeighbors = 0.0;
		
		double numInvestingNeighbors = 0.0;
		
		for (Investor i : neighbors)
		{
			numNeighbors++;
			
			if (i.isCurrentlyInvesting())
			{
				numInvestingNeighbors++;
			}
		}
		
		return numInvestingNeighbors / numNeighbors;
	}

	public boolean isCurrentlyInvesting()
	{
		return currentlyInvesting;
	}
	
	public void addNeighbor(Investor i)
	{
		neighbors.add(i);
	}
	
	public Set<Investor> getNeighbors()
	{
		return neighbors;
	}
}
