/*
  Copyright 2006 by Sean Luke and George Mason University
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
 */

// To run from command line:
// java -classpath .:../lib/mason13_small.jar:../lib/colt.jar sim.app.standingovation.StandingOvation -seed 1 -repeat 290 -until 100
package sim.app.ponzi;

import java.util.ArrayList;
import java.util.List;

import sim.engine.*;
import sim.field.grid.*;

public/* strictfp */class PonziScheme extends SimState
{

	public static final double TOTAL_NUM_AGENTS = 100;
	
	public static final int RED = 2;  // investor

	public static final int BLUE = 3; // non-investor
	
	public List<Investor> investors = new ArrayList<Investor>();
	
	public static boolean USE_DATA = true;
	
	public Bernie bernie;
	
	public Market market;
	
	public double amountOfOverReporting = .02;
	
	public double meanInvestorMarketThreshold = .07;
	
	public double sdInvestorMarketThreshold = 0.01;
	
	public double meanWeightInvestorMarketThreshold = 0.05;
	
	public double sdWeightInvestorMarketThreshold = 0.01;
	
	public double meanInvestorSocialThreshold = 0.5;
	
	public double sdInvestorSocialThreshold = 0.1;
	
	public double meanWeightInvestorSocialThreshold = 0.05;
	
	public double sdWeightInvestorSocialThreshold = 0.01;

	public static final int LANDSCAPE_WIDTH = (int) Math.ceil(Math
		.sqrt(TOTAL_NUM_AGENTS));

	public static final int LANDSCAPE_HEIGHT = (int) Math.floor(Math
		.sqrt(TOTAL_NUM_AGENTS));

	public static int gridHeight;

	public static int gridWidth;

	public static boolean landscapeToroidal = true;

	public IntGrid2D neighbors;
	
	public int maxNumNeighbors = 5;

	// we presume that no one relies on these DURING a simulation
	public int getGridHeight()
	{
		return gridHeight;
	}

	public void setGridHeight(int val)
	{
		if (val > 0)
			gridHeight = val;
	}

	public int getGridWidth()
	{
		return gridWidth;
	}

	public void setGridWidth(int val)
	{
		if (val > 0)
			gridWidth = val;
	}

	public static boolean runningBatchMode = false;

	/** Creates a Schelling simulation with the given random number seed. */
	public PonziScheme(long seed)
	{
		this(seed, LANDSCAPE_WIDTH, LANDSCAPE_HEIGHT); 
	}

	public PonziScheme(long seed, int width, int height)
	{
		super(seed);

		gridWidth = width;
		gridHeight = height;
		createGrids();
	}

	protected void createGrids()
	{
		neighbors = new IntGrid2D(gridWidth, gridHeight, 0);
		int[][] g = neighbors.field;
		for (int x = 0; x < gridWidth; x++)
			for (int y = 0; y < gridHeight; y++)
			{
				g[x][y] = BLUE;
			}
	}
	
	/** Resets and starts a simulation */
	public void start()
	{
		super.start(); // clear out the schedule

		market = new Market(this);
		
		schedule.scheduleRepeating(market, 0, 1);
		
		bernie = new Bernie(this);
		
		schedule.scheduleRepeating(bernie, 10, 1);
			
		// make new grids
		createGrids();
		
		for (int x = 0; x < gridWidth; x++)
		{
			for (int y = 0; y < gridHeight; y++)
			{
				Investor investor = new Investor(x, y, this);
				
				investors.add(investor);
				
				// TODO:  Add agents
			}
		}
		
		investors.get(0).addNeighbor(investors.get(1));
		investors.get(1).addNeighbor(investors.get(0));
		
		int totalNumInvestors = 2;
		int totalNumEdges = 2;
		
		for (int i = 2; i < investors.size(); i++)
		{
			Investor investor = investors.get(i);
			
			int numNeighbors = random.nextInt(maxNumNeighbors) + 1;
			
			int numNewEdges = 0;
			int numTotalEdges = 0;
			
			for (int j = 0; j < numNeighbors; j++)
			{
				// Pick a random investor to connect to
				
				Investor neighborInvestor = getRandomNeighbor(i, totalNumEdges);
				
				if (!investor.getNeighbors().contains(neighborInvestor))
				{
					investor.addNeighbor(neighborInvestor);
					neighborInvestor.addNeighbor(investor);
				
					numNewEdges += 2;
				}
			}
			
			numTotalEdges += numNewEdges;
			
			totalNumInvestors++;
			
			
			schedule.scheduleRepeating(investor, 20, 1);
		}
	}
	
	public Investor getRandomNeighbor(int i, double totalNumEdges)
	{
		double randNumber = random.nextDouble();
	
		for (int k = 0; k < i; k++)
		{
			double numberNeighborsKthInvestor = investors.get(k).getNumberNeighbors();
		
			double probConnectingToKthInvestor = numberNeighborsKthInvestor / totalNumEdges;
		
			randNumber = randNumber - probConnectingToKthInvestor;
			
			if (randNumber < 0)
			{
				return investors.get(k);
			}
		}
		
		System.err.println("Should not get here in getRandomNeighbor");
		return null;
	}

	public static void main(String[] args)
	{
		PonziScheme.runningBatchMode = true;

		doLoop(PonziScheme.class, args);

		System.exit(0);
	}

	public double getPercentageInvestor()
	{
		double numInvesting = 0;
		double totalInvestors = 0;
		
		for (Investor i : investors)
		{
			totalInvestors++;
			
			if (i.isCurrentlyInvesting())
			{
				numInvesting++;
			}
		}

		return numInvesting / totalInvestors;
	}

	public static boolean isLandscapeToroidal()
	{
		return landscapeToroidal;
	}

	public static void setLandscapeToroidal(boolean landscapeToroidal)
	{
		PonziScheme.landscapeToroidal = landscapeToroidal;
	}
	
	public Market getMarket()
	{
		return market;
	}

	public Bernie getBernie()
	{
		return bernie;
	}
	
	public List<Investor> getInvestors()
	{
		return investors;
	}

	public int getMaxNumNeighbors() {
		return maxNumNeighbors;
	}

	public void setMaxNumNeighbors(int maxNumNeighbors) {
		this.maxNumNeighbors = maxNumNeighbors;
	}

	public double getMeanInvestorMarketThreshold() {
		return meanInvestorMarketThreshold;
	}

	public void setMeanInvestorMarketThreshold(double meanInvestorMarketThreshold) {
		this.meanInvestorMarketThreshold = meanInvestorMarketThreshold;
	}

	public double getMeanInvestorSocialThreshold() {
		return meanInvestorSocialThreshold;
	}

	public void setMeanInvestorSocialThreshold(double meanInvestorSocialThreshold) {
		this.meanInvestorSocialThreshold = meanInvestorSocialThreshold;
	}

	public double getMeanWeightInvestorMarketThreshold() {
		return meanWeightInvestorMarketThreshold;
	}

	public void setMeanWeightInvestorMarketThreshold(
			double meanWeightInvestorMarketThreshold) {
		this.meanWeightInvestorMarketThreshold = meanWeightInvestorMarketThreshold;
	}

	public double getMeanWeightInvestorSocialThreshold() {
		return meanWeightInvestorSocialThreshold;
	}

	public void setMeanWeightInvestorSocialThreshold(
			double meanWeightInvestorSocialThreshold) {
		this.meanWeightInvestorSocialThreshold = meanWeightInvestorSocialThreshold;
	}

	public double getSdInvestorMarketThreshold() {
		return sdInvestorMarketThreshold;
	}

	public void setSdInvestorMarketThreshold(double sdInvestorMarketThreshold) {
		this.sdInvestorMarketThreshold = sdInvestorMarketThreshold;
	}

	public double getSdInvestorSocialThreshold() {
		return sdInvestorSocialThreshold;
	}

	public void setSdInvestorSocialThreshold(double sdInvestorSocialThreshold) {
		this.sdInvestorSocialThreshold = sdInvestorSocialThreshold;
	}

	public double getSdWeightInvestorMarketThreshold() {
		return sdWeightInvestorMarketThreshold;
	}

	public void setSdWeightInvestorMarketThreshold(
			double sdWeightInvestorMarketThreshold) {
		this.sdWeightInvestorMarketThreshold = sdWeightInvestorMarketThreshold;
	}

	public double getSdWeightInvestorSocialThreshold() {
		return sdWeightInvestorSocialThreshold;
	}

	public void setSdWeightInvestorSocialThreshold(
			double sdWeightInvestorSocialThreshold) {
		this.sdWeightInvestorSocialThreshold = sdWeightInvestorSocialThreshold;
	}

	public static boolean isUSE_DATA() {
		return USE_DATA;
	}

	public static void setUSE_DATA(boolean use_data) {
		USE_DATA = use_data;
	}

}
