/*
  Copyright 2006 by Sean Luke and George Mason University
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
 */

package sim.app.ponzi;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import sim.engine.*;

public/* strictfp */class Market implements Steppable
{
	public double trueROI = 0;
	
	public LinkedList<Double> prices = new LinkedList<Double>();
	
	public List<Double> yearlyRateOfReturn = new ArrayList<Double>();
	
	public int currentIndex = 0;
	
	public Market(final SimState state)
	{
		prices.clear();
		currentIndex = 0;
		
		try 
		{
			BufferedReader reader = new BufferedReader(new FileReader("data_spy.csv"));
			
			reader.readLine();
			
			String s;
			
			while((s = reader.readLine()) != null) 
			{
				String[] strs = s.split(",");
				
				double price = Double.parseDouble(strs[4]);
				
				// Got to add first because data goes from newest to oldest
				prices.addFirst(new Double(price));
			} 
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		for (int i = 0; i+52 < prices.size(); i++)
		{
			yearlyRateOfReturn.add(new Double(calculateYearlyRateOfReturn(i)));
		}
		
		for (Double d : yearlyRateOfReturn)
		{
			System.err.print(d + "   ");
		}
		
		System.err.println();
	}
	
	public double calculateYearlyRateOfReturn(int startingIndex)
	{
		double earlyPrice = prices.get(startingIndex).doubleValue();
		
		double endPrice = prices.get(startingIndex + 52).doubleValue();
		
		return (endPrice - earlyPrice) / earlyPrice;
	}

	public void step(final SimState state)
	{
		PonziScheme ponziScheme = (PonziScheme) state;

		if (ponziScheme.USE_DATA)
		{
			trueROI = yearlyRateOfReturn.get(currentIndex).doubleValue();
			currentIndex++;
		}
		else
		{
			trueROI = .05;
			
			//trueROI = trueROI + (state.random.nextDouble()-0.25)/10.0;
		}
	}
	
	public double getTrueROI()
	{
		return trueROI;
	}
}
