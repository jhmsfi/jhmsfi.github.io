% This simple function clears the aisles, if possible without moving anyone
% into a different row.

function [output] = aisle(state)

for i = 1:3
    if state(i,2) ~=0
        if state(i,1) == 0
            state(i,1) = state(i,2);
            state(i,2) = 0;
        elseif state(i,3) == 0
            state(i,3) = state(i,2);
            state(i,2) = 0;
        end
    end
end

output = state;