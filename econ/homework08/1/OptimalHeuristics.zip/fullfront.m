%This function allows agents, starting from the middle row and moving left to right, to look behind
%them. If there is room, they take a step backwards

function [output] = fullfront(state)
for j = -2:-1
    for k = 1:3
        if state(-j+1,k)==0
            state(-j+1,k) = state(-j,k);
            state(-j,k) = 0;
        end
    end
end
output = state;