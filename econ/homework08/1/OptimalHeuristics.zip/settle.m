% This function assumes that we have guaranteed that there is room in row
% j. Now, the agent of type x settles down, preferring the leftmost to the
% rightmost to the middle.

function [output] = settle(state,j,x)
if state(j,1) == 0
    state(j,1) = x;
elseif state(j,3)==0
    state(j,3) = x;
else 
    state(j,2)= x;
end
output = state;
