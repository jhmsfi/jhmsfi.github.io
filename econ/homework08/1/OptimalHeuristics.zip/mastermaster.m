k = 5;
count = 1
result = zeros(20,6);
for p = 1:4:20
    for n = 2:2:8
        [a, b , c , d] = master(n,k,p);
        result(count,1:6) = [n,p,a,b,c,d];
        count = count+1
    end
end
save result

