function [output] = exit(state, k, strat,penalty)

for i = 1:3
    for j = 1:3
        if state(i,j) == k
            state(i,j) = 0;
            state(4,1) = state(4,1) + i;
            state(4+k,1) = state(4,1);
            if i == 2
                if state(1,2) ~= 0
                    y = state(1,2);
                    state(1,2) = 0;
                    state = entry(state,y,strat,penalty);
                end
            elseif i == 3
                if state(2,2) ~= 0 & state(1,2) ~= 0
                    y = state(2,2);
                    z = state(1,2);
                    state(1,2) = 0;
                    state(2,2) = 0;
                    state = entry(state,y,strat,penalty);
                    state = entry(state,z,strat,penalty);
                elseif state(2,2) ~= 0 & state(1,2)==0
                    y = state(2,2);
                    state(2,2) = 0;
                    if state(1,1)==0
                        state(2,2) = 0;
                        state(1,1) = y;
                    elseif state(1,3)==0
                        state(2,2) = 0;
                        state(1,3) = y;
                    else
                        state = entry(state,y,strat,penalty);
                    end
                elseif state(1,2) ~= 0 & state(2,2)==0
                    y = state(1,2);
                    state(1,2) = 0;
                    state = entry(state,y,strat,penalty);
                end
            end
            output = state;
            return
        end
    end
end
error('nobody to exit')
            
            
          