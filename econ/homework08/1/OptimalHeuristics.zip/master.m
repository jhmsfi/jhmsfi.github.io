% n = number of arrivals. NB: <= 9
% k = number of floors.
% penalty represents the confusion penalty for everone moving back at once
% the results from this file are the minimum mean ticks and the argmin in
% the five-dimensional strategy space

function [ticks, onez, twoz, monotone] = master(n,k,penalty)

A = [];

k = 5;
    for a = 1:3
        for b = 1:3
            for c = 1:3
                for d = 1:3
                    for e = 1:3
                        for r = 1:500
                            
strat = [a;b;c;d;e];

R(r) = optimaster(n, k, strat, penalty);

A(a,b,c,d,e) = mean(R);

                        end
                    end
                end
            end
        end
    end
    
minimean = A(1,1,1,1,1);
argmin = [1,1,1,1,1];
for a = 1:3
        for b = 1:3
            for c = 1:3
                for d = 1:3
                    for e = 1:3
                        if A(a,b,c,d,e) < minimean
                            minimean = A(a,b,c,d,e);
                            argmin = [a,b,c,d,e];
                        end
                    end
                end
            end
        end
end
ticks = minimean;
opstrat = argmin;
ones = 0;
twos = 0;
for i = 1:k;
    if opstrat(i) == 1
        ones = ones + 1;
    elseif opstrat(i) == 2
        twos = twos + 1;
    end
end
onez = ones;
twoz = twos;
opstrat;
tag = 1;
base = opstrat(1);
for i = 2:k
    if base > opstrat(i)
        tag = 0;
    end
    base = opstrat(i);
end
monotone = tag;

