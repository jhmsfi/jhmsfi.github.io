% This function adds a player of type x to the elevator characterized by
% "state", using the strategy vector.

function [output] = entry(state, x, strat, penalty)

state(4,1) = state(4,1) + 1;

% Entrance blocked
if state(1,2) ~= 0
    state = fullfront(state);
    state(4,1) = state(4,1) + penalty;
end

% Choosing a spot
if strat(x)==1 | state(2,2) ~= 0
    state = settle(state,1,x);
    state(4,1) = state(4,1);
elseif strat(x)==2 | state(3,2) ~=0
    state = settle(state,2,x);
    state(4,1) = state(4,1) + 1;
else
    state = settle(state,3,x);
    state(4,1) = state(4,1) + 2;
end

output = state;
    