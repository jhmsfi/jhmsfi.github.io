// Guest.h					Cocktail

#import <objectbase/SwarmObject.h>
#import <gui.h>
#import <collections.h>

@interface Guest: SwarmObject
{
  int numOfGuests;
  int roomSize;
  double vision;
  double velocity;
  double contactDistance;
  double attractionDecay;
  int agentID;
  double zoomFactor;
 
  double attraction[21];
  double xPos, yPos;
 
  id uniformDoubleDist;
  id uniformIntegerDist;
  
  id guestList;
  id favoriteNeighbor;

  id <NodeItem> guestNode;   // the node for the canvas
  id myCanvas;  // the Canvas

}

- setNumOfGuests: (int) nog;
- setRoomSize: (int) rs;
- setVision: (double) vis;
- setContactDistance: (double) cd;
- setAttractionDecay: (double) ad;
- setAgentID: (int) i;
- setGuestList: (id) gl;
- setZoomFactor: (double) zf;

- setUniformDoubleDist: (id) ud;
- setUniformIntegerDist: (id) ui;

- setInitialPosition;
- setNode: (id) aCanvas;
- setMyCanvas: (id) sc; 

- (double) calculateDistance: (id) otherGuest;
- findFavoriteNeighbor;
- moveInRoom;
- adjustAttraction;
- leaveParty;

- createEnd;

//- step;

- (int) getAgentID;
- (double) getXPos;
- (double) getYPos;


@end

