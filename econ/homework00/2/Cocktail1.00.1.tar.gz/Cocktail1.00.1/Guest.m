// Guest.m					Cocktail

#import "Guest.h"
#import <random.h>

@implementation Guest

- setNumOfGuests: (int) nog {
  numOfGuests = nog;
  return self;
}

- setRoomSize: (int) rs {
  roomSize= rs;
  return self;
}

- setVision: (double) vis {
  vision= vis;
  return self;
}

- setContactDistance: (double) cd {
  contactDistance= cd;
  return self;
}

- setAttractionDecay: (double) ad {
  attractionDecay= ad;
  return self;
}

- setAgentID: (int) i {
  agentID= i;
  return self;
}

- setGuestList: (id) gl {
  guestList= gl;
  return self;
}

- setUniformDoubleDist: (id) ud {  
  uniformDoubleDist=ud;
  return self;
}

- setUniformIntegerDist: (id) ui { 
  uniformIntegerDist=ui;
  return self;
}

- setInitialPosition {
  int i;
  xPos=(double)[uniformDoubleDist getDoubleWithMin: 0 withMax: roomSize];
  yPos=(double)[uniformDoubleDist getDoubleWithMin: 0 withMax: roomSize];
  
  for (i=0; i<numOfGuests; i++) {
    attraction[i]=(double)[uniformDoubleDist getDoubleWithMin: 0 withMax: 1];
    if (agentID==i) 
      attraction[i]=0.0;
  }

  return self;
}

-setNode: (id) aCanvas {
  char *aName;

  aName=xmalloc(10);
  sprintf(aName,"A%d", agentID);

  guestNode = [OvalNodeItem createBegin: [self getZone]];
  [guestNode setCanvas: aCanvas];
 
  [guestNode setX: (zoomFactor * xPos) Y: (zoomFactor * yPos)];
  
  //printf("The position of %d is %d, %d \n", agentID, [guestNode getX], [guestNode getY]);
  [guestNode setString: aName];
  [guestNode setTargetId: self];
  guestNode=[guestNode createEnd];
  return self;
}

-setMyCanvas: (id) sc {
  myCanvas=sc;
  return self;
}

-setZoomFactor: (double) zf {
  zoomFactor= zf;
  return self;
}

-(double) calculateDistance: (id) otherGuest {
  double distance;
  double xOth, yOth;
  double distX, distY;

  xOth=[otherGuest getXPos];
  yOth=[otherGuest getYPos];

  distX=(xPos-xOth) * (xPos-xOth);
  distY=(yPos-yOth) * (yPos-yOth);

  distance=(double)sqrt(distX + distY);
 
  return distance;
}

- findFavoriteNeighbor {
  id <Index> pplIndex = nil;
  id aGuest = nil;
  id favoriteGuest = nil;
  int favGuestID = -50;
  int aGuestID;

  pplIndex = [guestList begin: [self getZone]];
  while ([pplIndex next]) 
    {
      aGuest=[pplIndex get];
      aGuestID=[aGuest getAgentID];
      if ([self calculateDistance: aGuest] < vision)
	{
	  if (favoriteGuest != nil)
	    {
	      if (attraction[aGuestID]>attraction[favGuestID])
		favoriteGuest=aGuest;
	    }
	  else
	    {
	      favoriteGuest=aGuest;
	      favGuestID=[favoriteGuest getAgentID];
	    }
	}
    }
  [pplIndex drop];
  
  favoriteNeighbor=favoriteGuest;

  return self;
}

-moveInRoom {
  double deltaX, deltaY;
  double deltaX2, deltaY2;
  int favID=[favoriteNeighbor getAgentID];

  if (([self calculateDistance: favoriteNeighbor] > contactDistance) &&  (attraction[favID]>0)){
    deltaX=([favoriteNeighbor getXPos] - xPos)/2;
    deltaY=([favoriteNeighbor getYPos] - yPos)/2;
    
    [guestNode moveX: (int) (zoomFactor * deltaX)  Y: (int) (zoomFactor * deltaY) ];
  
    xPos=xPos + deltaX;
    yPos=yPos + deltaY;

  }

  if (([self calculateDistance: favoriteNeighbor] < vision) &&  (attraction[favID]<0)){
    
    deltaX=-(([favoriteNeighbor getXPos] - xPos)/2);
    deltaY=-(([favoriteNeighbor getYPos] - yPos)/2);
    
    deltaX2=xPos;
    deltaY2=yPos;

    xPos=xPos + deltaX;
    if (xPos<0) {
      deltaX=-deltaX2;
      xPos=0;
    }

    if (xPos>100) {
      deltaX=100-deltaX2;
      xPos=100;
    }

    yPos=yPos + deltaY;
    if (yPos<0) {
      deltaY=-deltaY2;
      yPos=0;
    }

    if (yPos>100) {
      deltaY=100-deltaY2;
      yPos=100;
    }
    [guestNode moveX: (int) (zoomFactor * deltaX) Y: (int) (zoomFactor * deltaY) ];

   
  
  }
  
  //printf("I am agent %d, in position %1.2f,%1.2f and moving %1.2f,%1.2f ",agentID,xPos,yPos,deltaX,deltaY);
  //printf("toward %d \n", [favoriteNeighbor getAgentID]);

  return self;
}

-adjustAttraction {
  id <Index> pplIndex = nil;
  id aGuest = nil;
  int aGuestID;

  pplIndex = [guestList begin: [self getZone]];
  while ([pplIndex next]) 
    {
      aGuest=[pplIndex get];
      aGuestID=[aGuest getAgentID];
      if (([self calculateDistance: aGuest] < contactDistance) && (agentID != aGuestID))
	{	 
	  attraction[aGuestID]=attraction[aGuestID] - attractionDecay;
	}
    }
  [pplIndex drop];

  return self;
}

-leaveParty {
  id <Index> pplIndex = nil;
  id aGuest = nil;
  int aGuestID;
  int toLeave = 1;

  pplIndex = [guestList begin: [self getZone]];
  while ([pplIndex next]) 
    {
      aGuest=[pplIndex get];
      aGuestID=[aGuest getAgentID];
      if (([self calculateDistance: aGuest] < vision) && (agentID != aGuestID))
	{	 
	  if (attraction[aGuestID]>0)
	    toLeave=0;
	}
    }
  [pplIndex drop];

  if (toLeave==1)
    {
      [guestNode moveX: (int) 1000 Y: (int) 1000 ];
      xPos=1000;
      yPos=1000;
    }
  return self;
}

- createEnd
{
   [super createEnd];
   return self;
}

//- step
//{
  // int i;
  //int favID;

//printf("My name is %d and my position is %2.3f, %2.3f \n ", agentID, xPos, yPos); 
  //printf("   ");

  //for (i=0; i<numOfGuests; i++)
  //  printf(" %1.1f", attraction[i]);

//favoriteNeighbor=[self findFavoriteNeighbor];
//[self moveInRoom];
//[self adjustAttraction];

  //favID=[favoriteNeighbor getAgentID];
  
  //if (favoriteNeighbor!=nil) {
  //  printf(" My favorite neighbor %d ", [favoriteNeighbor getAgentID]);
  //  printf("his/her location is %1.2f, %1.2f ", [favoriteNeighbor getXPos], [favoriteNeighbor getYPos]);
  //  printf("our distance is %1.2f ", [self calculateDistance: favoriteNeighbor]);
  //  printf("my attraction is %1.2f ", attraction[favID]);
  
  //   printf("\n");
  //}

//return self;
//}

- (int) getAgentID {
  return agentID;
}

- (double) getXPos {
  return xPos;
}

- (double) getYPos {
  return yPos;
}


@end  


