// ModelSwarm.m					Cocktail 

#import "ModelSwarm.h"
#import <random.h>
#import <activity.h>
#import <simtools.h>

@implementation ModelSwarm  

// These methods provide access to the objects inside the ModelSwarm.
// These objects are the ones visible to other classes via message call.
// In theory we could just let other objects use Probes to read our state,
// but message access is frequently more convenient.


+ createBegin: (id) aZone
{
  ModelSwarm * obj;
  id <ProbeMap> probeMap;


  // in createBegin, we set up the simulation parameters

  // First, call our superclass createBegin - the return value is the
  // allocated BugSwarm object.

  obj = [super createBegin: aZone];

  // Now fill in various simulation parameters with default values.

  obj-> randomSeed=2354;
  obj-> numOfGuests=21;
  obj-> roomSize=100;
  obj-> vision=30.0;
  obj-> contactDistance=15.0;
  obj-> attractionDecay=0.05;
  obj-> filmIt=0;

  // Then create an EmptyProbeMap to hold the individual
  // probes for each simulation parameter
  probeMap = [EmptyProbeMap createBegin: aZone];
  [probeMap setProbedClass: [self class]];
  probeMap = [probeMap createEnd];

   // Add in a bunch of probes one per simulation parameter
  [probeMap addProbe: [probeLibrary getProbeForVariable: "randomSeed"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "numOfGuests"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "roomSize"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "vision"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "contactDistance"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "attractionDecay"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "filmIt"
				    inClass: [self class]]];
  // Now install our custom probeMap into the probeLibrary.
  [probeLibrary setProbeMap: probeMap For: [self class]];

  // We've created the ModelSwarm and initialized it.
  // return the id of the newly created Swarm

  return obj;
}

- createEnd
{
  return [super createEnd];
}

-setGraphCanvas: (id) aCanvas {
  graphCanvas = aCanvas;
  return self;
}

-setZoomFactor: (double) zf {
  zoomFactor = zf;
  return self;
}

-updateGraphics {
  GUI_UPDATE_IDLE_TASKS();
  return self;
}

-takeAPicture  {  
  char filename[40];
  
  if (filmIt) {
    sprintf(filename, "pic%07ld.png", getCurrentTime());
    //[actionCache doTkEvents];
    [[[[[[Pixmap createBegin: [self getZone]]
	  setWidget: graphCanvas]
	 setDecorationsFlag: NO]
	createEnd] save: filename] drop];
  }
  return self;
}


- buildObjects
{
  Guest * aGuest;
 
  int i;
  
  [super buildObjects];

  // Here, we create the objects in the model


  // Also some random number generators  //PMMLCG1
  aGenerator=[MT19937gen create: [self getZone] setStateFromSeed: randomSeed];
  uniformDoubleDist=[UniformDoubleDist create: [self getZone] setGenerator: aGenerator];
  uniformIntegerDist=[UniformIntegerDist create: [self getZone] setGenerator: aGenerator];


  // Now, create a bunch of bugs to live in the world

  guestList = [List create: self];

  for (i=0; i<numOfGuests; i++)
    {
      aGuest = [Guest createBegin: self];
      [aGuest setNumOfGuests: numOfGuests];
      [aGuest setRoomSize: roomSize];
      [aGuest setVision: vision];
      [aGuest setContactDistance: contactDistance];
      [aGuest setAgentID: i];
      [aGuest setUniformDoubleDist: uniformDoubleDist];
      [aGuest setUniformIntegerDist: uniformIntegerDist];
      [aGuest setGuestList: guestList];
      [aGuest setAttractionDecay: attractionDecay];
      [aGuest setZoomFactor: zoomFactor];
      aGuest = [aGuest createEnd];
      [aGuest setInitialPosition];
      [aGuest setNode: graphCanvas];
      [aGuest setMyCanvas: graphCanvas];

      [guestList addLast: aGuest];
    }

  return self;
}

- buildActions
{
  // Create the list of simulation actions. 
  
  modelActions = [ActionGroup create: self];
  [modelActions createActionForEach: guestList    message: M(leaveParty)];
  [modelActions createActionForEach: guestList    message: M(findFavoriteNeighbor)];
  [modelActions createActionForEach: guestList    message: M(moveInRoom)];
  [modelActions createActionForEach: guestList    message: M(adjustAttraction)];
  [modelActions createActionTo: self message: M(updateGraphics)];
  [modelActions createActionTo: self message: M(takeAPicture)];
  
  // Then we create a schedule that executes the modelActions. 
  
  modelSchedule = [Schedule createBegin: self];
  [modelSchedule setRepeatInterval: 1];
  modelSchedule = [modelSchedule createEnd];
  [modelSchedule at: 0 createAction: modelActions]; 
  
  return self;
  
}

- activateIn: swarmContext
{
  // Here, we activate the swarm in the context passed in
  // Then we activate our schedule in ourselves
  
  [super activateIn: swarmContext];
  
  [modelSchedule activateIn: self];
  
  return [self getSwarmActivity];
}

@end



  


