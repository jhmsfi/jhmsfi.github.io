// ObserverSwarm.m                              Cocktail

#import "ObserverSwarm.h"
#import "ModelSwarm.h"
#import <simtoolsgui.h>

@implementation ObserverSwarm

+ createBegin: (id) aZone {
  ObserverSwarm *obj;
  id <ProbeMap> probeMap;

  // createBegin: here we set up the default simulation parameters.

  // Superclass createBegin to allocate ourselves.

  obj = [super createBegin: aZone];

  // Fill in the relevant parameters (only one, in this case).

  obj->displayFrequency = 1;
  obj->zoomFactor = 5;

  // Also, build a customized probe map. Without a probe map, the default
  // is to show all variables and messages. Here we choose to
  // customize the appearance of the probe, give a nicer interface.
  probeMap = [EmptyProbeMap createBegin: aZone];
  [probeMap setProbedClass: [self class]];
  probeMap = [probeMap createEnd];

  // Add in a bunch of variables, one per simulation parameters
  [probeMap addProbe: [probeLibrary getProbeForVariable: "displayFrequency"
				    inClass: [self class]]];
  [probeMap addProbe: [probeLibrary getProbeForVariable: "zoomFactor"
				    inClass: [self class]]];

  // Now install our custom probeMap into the probeLibrary.
  [probeLibrary setProbeMap: probeMap For: [self class]];


  return obj;
}


- buildObjects
{
  id modelZone;

  [super buildObjects];
  
  //[actionCache waitForControlEvent];

  //if([controlPanel getState]==ControlStateQuit)
  //  return self;
  
  // First, we create the model that we will be observing
  modelZone=[Zone create: [self getZone]];
  modelSwarm=[ModelSwarm create: modelZone];

  [probeDisplayManager createProbeDisplayFor: modelSwarm];
  [probeDisplayManager createProbeDisplayFor: self];

  [controlPanel setStateStopped];

  // Check now if the user hit the quit button: if so, abort.
  if ([controlPanel getState] == ControlStateQuit) return self;

  //  The graphCanvas is where we will display the room
  graphCanvas=[Canvas createBegin: [self getZone]];
  SET_WINDOW_GEOMETRY_RECORD_NAME (graphCanvas);
  graphCanvas=[graphCanvas createEnd];

  [[graphCanvas setHeight: (int)(zoomFactor * 100)] setWidth: (int) (zoomFactor * 100)];
  [graphCanvas setWindowTitle: "A Cocktail Party"];
  [graphCanvas packFillLeft: YES];
  GUI_UPDATE_IDLE_TASKS();

  [modelSwarm setGraphCanvas: graphCanvas];
  [modelSwarm setZoomFactor: zoomFactor];

  // OK - the user said "go" so we're ready to start

  [modelSwarm buildObjects];

  // Now get down to building our own display objects.
  [probeDisplayManager update];
  [actionCache doTkEvents];

  GUI_UPDATE_IDLE_TASKS();
 
  return self;
}

- buildActions
{

  [super buildActions];
  
  // First, let our model swarm build its own schedule.

  [modelSwarm buildActions];

  // Create an ActionGroup for display: a bunch of things that occur in
  // a specific order, but at one step of simulation time. Some of these
  // actions could be executed in parallel, but we don't explicitly
  // notate that here.

  displayActions = [ActionGroup create: self];

  // Schedule up the methods to draw the display of the world

  //[displayActions createActionTo: foodDisplay         message: M(display)];
  //[displayActions createActionTo: bugDisplay          message: M(display)];
  //[displayActions createActionTo: worldRaster         message: M(drawSelf)];

  [displayActions createActionTo: actionCache         message: M(doTkEvents)];

  // And the display schedule. Note the repeat interval is set from our
  // own Swarm data structure. Display is frequently the slowest part of a
  // simulation, so redrawing less frequently can be a help.

  displaySchedule = [Schedule createBegin: self];
  [displaySchedule setRepeatInterval: displayFrequency]; // note frequency!
  displaySchedule = [displaySchedule createEnd];
  [displaySchedule at: 0 createAction: displayActions];
 
  return self;
}

- activateIn: swarmContext
{
  
// activateIn: - activate the schedules so they're ready to run.
// The swarmContext argument has to do with what we were activated *in*.
// Typically the ObserverSwarm is the top-level Swarm, so it's activated
// in "nil". But other Swarms and Schedules and such will be activated
// inside of us.

  [super activateIn: swarmContext];

  // Activate the model swarm in ourselves. The model swarm is a
  // subswarm of the observer swarm.

  [modelSwarm activateIn: self];

  // Now activate our schedule in ourselves. This arranges for the
  // execution of the schedule we built.

  [displaySchedule activateIn: self];

  // Activate returns the swarm activity - the thing that's ready to run.

  return [self getSwarmActivity];
}

@end

