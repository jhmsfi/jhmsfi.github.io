// ModelSwarm.h					Cocktail

#import "Guest.h"
#import <objectbase/Swarm.h>
#import <space.h>

@interface ModelSwarm: Swarm
{
  int randomSeed;
  int numOfGuests;
  int roomSize;
  double vision;
  double contactDistance;
  double attractionDecay;
  BOOL filmIt;
  double zoomFactor;

  id guestList;
  id graphCanvas;

  id modelActions;
  id modelSchedule;

  id  aGenerator;
  id  uniformDoubleDist;
  id  uniformIntegerDist;  

  id guestNode;
}

+ createBegin: aZone;
- createEnd;
- setGraphCanvas: (id) aCanvas;
- setZoomFactor: (double) zf;
- updateGraphics;
- takeAPicture;
- buildObjects;
- buildActions;
- activateIn: swarmContext;

@end


