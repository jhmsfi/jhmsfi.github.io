// ObserverSwarm.h                                     Cocktail

#import "ModelSwarm.h"
#import <simtoolsgui/GUISwarm.h>
#import <simtoolsgui.h>
#import <objectbase.h>
#import <gui.h>
#import <tkobjc/Graph.h>

@interface ObserverSwarm: GUISwarm
{
  int displayFrequency;                           // one parameter: update freq
  double zoomFactor;

  id displayActions;                              // schedule data structs
  id displaySchedule;

  ModelSwarm *modelSwarm;          		  // the Swarm we're observing
  
  id graphCanvas; // Holds the graph nodes

  // Lots of display objects. First, widgets


 // Now, higher order display and data objects

}

// Methods overriden to make the Swarm.

+ createBegin: aZone;

- buildObjects;
- buildActions;
- activateIn: swarmContext;

@end

